module FavoritesHelper
end
