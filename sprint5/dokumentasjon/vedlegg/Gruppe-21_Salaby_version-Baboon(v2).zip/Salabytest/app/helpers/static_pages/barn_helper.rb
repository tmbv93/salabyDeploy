module StaticPages::BarnHelper
end
