module StaticPages::Barn::RleHelper
end
