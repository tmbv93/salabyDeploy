module StaticPages::InfoHelper
end
