module DepartmentMembersHelper

  def find_by_user_id

  end

end
