module SchoolsHelper
end
