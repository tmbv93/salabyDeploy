class Homework < ActiveRecord::Base

  #belongs_to game
  #belongs_to department
end
