class StaticPages::BarnController < ApplicationController
  def forside
  end

  def hinduisme
  end

  def rle
  end

  def islam
  end
end
