class StaticPages::InfoController < ApplicationController
  def bestilling
  end

  def informasjon
  end

  def kompetanse
  end

  def omByparken
  end

  def omKanalS
  end

  def omSalaby
  end

  def omSkoleveien
  end

  def forside
  end
end
