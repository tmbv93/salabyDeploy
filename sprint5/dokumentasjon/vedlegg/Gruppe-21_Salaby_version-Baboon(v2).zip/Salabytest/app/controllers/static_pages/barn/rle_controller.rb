class StaticPages::Barn::RleController < ApplicationController
  def islam
  end

  def jodedom
  end

  def hinduisme
  end

  def buddhisme
  end

  def kristendom
  end

  def sikhisme
  end

  def etikk_filosofi
  end

  def kunst
  end

  def kirkehistorie
  end
end
