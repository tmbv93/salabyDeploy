class StaticPagesController < ApplicationController
  def home
  end

  def help
  end

  def info_pages_bestilling_path
  end

end
