# encoding: UTF-8
# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20150305084006) do

  create_table "department_members", force: true do |t|
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "user_id"
    t.integer  "department_id"
  end

  add_index "department_members", ["department_id"], name: "index_department_members_on_department_id"
  add_index "department_members", ["user_id"], name: "index_department_members_on_user_id"

  create_table "departments", force: true do |t|
    t.string   "name"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "schoolyear"
    t.text     "description"
  end

  create_table "favorites", force: true do |t|
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "games", force: true do |t|
    t.string   "title"
    t.integer  "category"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "homeworks", force: true do |t|
    t.string   "title"
    t.text     "description"
    t.integer  "class_id"
    t.integer  "game_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.date     "expiration"
  end

  add_index "homeworks", ["class_id"], name: "index_homeworks_on_class_id"
  add_index "homeworks", ["game_id"], name: "index_homeworks_on_game_id"

  create_table "schools", force: true do |t|
    t.string   "name"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "users", force: true do |t|
    t.string   "first_name"
    t.string   "last_name"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "status"
    t.string   "password_digest"
    t.string   "username"
    t.text     "description"
  end

end
