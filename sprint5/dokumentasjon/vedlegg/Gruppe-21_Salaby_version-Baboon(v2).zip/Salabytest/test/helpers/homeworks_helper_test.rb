require 'test_helper'

class HomeworksHelperTest < ActionView::TestCase
end
