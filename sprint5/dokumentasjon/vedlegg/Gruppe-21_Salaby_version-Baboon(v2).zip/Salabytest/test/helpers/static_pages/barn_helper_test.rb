require 'test_helper'

class StaticPages::BarnHelperTest < ActionView::TestCase
end
