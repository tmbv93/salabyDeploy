require 'test_helper'

class StaticPages::InfoHelperTest < ActionView::TestCase
end
