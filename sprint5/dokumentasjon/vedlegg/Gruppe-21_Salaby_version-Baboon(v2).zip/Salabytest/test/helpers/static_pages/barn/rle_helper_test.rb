require 'test_helper'

class StaticPages::Barn::RleHelperTest < ActionView::TestCase
end
