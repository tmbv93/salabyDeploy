require 'test_helper'

class FavoritesHelperTest < ActionView::TestCase
end
