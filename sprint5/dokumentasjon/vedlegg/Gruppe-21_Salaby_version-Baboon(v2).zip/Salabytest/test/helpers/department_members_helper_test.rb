require 'test_helper'

class DepartmentMembersHelperTest < ActionView::TestCase
end
